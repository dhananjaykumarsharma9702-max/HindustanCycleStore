# Hindustan Cycle Store — Android Starter

यह Version 1 starter app है। इसमें demo products, categories और cart मौजूद हैं।

## दुकान
Mobile: 9708809702
Address: Rajapatti, Baikunthpur, Gopalganj, Bihar

## कैसे चलाएँ
1. Android Studio खोलें।
2. इस project folder को Open करें।
3. Gradle sync पूरा होने दें।
4. Android phone/emulator चुनें।
5. Run दबाएँ।

अगले version में Firebase database, real product photos, customer orders, admin panel और payment integration जोड़े जा सकते हैं।
