package com.hindustancyclestore

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Product(val name:String, val category:String, val price:Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StoreApp() }
    }
}

@Composable
fun StoreApp() {
    val products = remember {
        listOf(
            Product("Hero City Cycle", "Cycles", 6500),
            Product("Mountain Cycle", "Cycles", 8500),
            Product("Cycle Tyre", "Tyres & Tubes", 650),
            Product("Cycle Tube", "Tyres & Tubes", 220),
            Product("LED Cycle Light", "Accessories", 180),
            Product("Cycle Lock", "Accessories", 250),
            Product("Brake Set", "Spare Parts", 300),
            Product("Chain", "Spare Parts", 350)
        )
    }
    var selected by remember { mutableStateOf("All") }
    var cart by remember { mutableStateOf(listOf<Product>()) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Hindustan Cycle Store") }) }
        ) { pad ->
            LazyColumn(
                modifier = Modifier.padding(pad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Cycles & Cycle Parts", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("All","Cycles","Spare Parts","Tyres & Tubes","Accessories").forEach {
                            FilterChip(selected = selected==it, onClick={selected=it}, label={Text(it)})
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Cart: ${cart.size} item(s)", style = MaterialTheme.typography.titleMedium)
                }
                val shown = products.filter { selected=="All" || it.category==selected }
                items(shown) { p ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text(p.name, style=MaterialTheme.typography.titleLarge)
                            Text(p.category)
                            Text("₹${p.price}", style=MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            Button(onClick={cart = cart + p}) { Text("Add to Cart") }
                        }
                    }
                }
                item {
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = { }) {
                        Text("Order / Contact: 9708809702")
                    }
                    Text("Rajapatti, Baikunthpur, Gopalganj, Bihar", modifier=Modifier.padding(top=8.dp))
                }
            }
        }
    }
}
